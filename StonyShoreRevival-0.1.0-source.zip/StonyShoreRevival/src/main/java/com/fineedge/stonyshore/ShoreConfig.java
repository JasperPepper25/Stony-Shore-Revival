package com.fineedge.stonyshore;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class ShoreConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue POOLS;
    public static final ForgeConfigSpec.BooleanValue SPIRES;
    public static final ForgeConfigSpec.BooleanValue COLD;
    public static final ForgeConfigSpec.DoubleValue STONE_CHANCE;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> EXTRA_ROCKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Generation happens only in new chunks. These settings belong on the server.").push("generation");
        STONE_CHANCE = b.comment("Chance to texture a naturally exposed stone face; 0 keeps original stone.")
            .defineInRange("stone_replacement_chance", 0.42, 0.0, 1.0);
        POOLS = b.define("tide_pools", true);
        SPIRES = b.define("stone_spires", true);
        COLD = b.define("cold_shores", true);
        EXTRA_ROCKS = b.comment("Optional block IDs, e.g. modid:block. Missing IDs are ignored. Prefer full cube stone-like blocks.")
            .defineListAllowEmpty("extra_rocks", List::of, o -> o instanceof String s && s.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"));
        b.pop();
        SPEC = b.build();
    }

    private ShoreConfig() {}
}
